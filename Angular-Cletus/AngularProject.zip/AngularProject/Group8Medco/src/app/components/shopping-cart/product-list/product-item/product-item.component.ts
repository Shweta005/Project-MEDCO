import { Component, OnInit, Input } from '@angular/core';
import { Iuser } from 'src/app/Iproduct';
import { Product } from 'src/app/models/product'
import { MessengerService } from 'src/app/services/messenger.service'
import {ServiceService} from 'src/app/services/user.service';
@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {

  @Input() productItem: Iuser;
  
  users : Iuser [] = [];
  constructor(private msg: MessengerService,private dataService:ServiceService) { }


  ngOnInit() {
    this.getUsers();
  }

  handleAddToCart() {
    this.msg.sendMsg(this.productItem)
  }

  getUsers(){

    this.dataService.getUsers().subscribe(allUsers => this.users = allUsers );
 
  }
}
