import { Component, OnInit } from '@angular/core';

import { ProductService } from 'src/app/services/product.service'
import { Product } from 'src/app/models/product';

import {ServiceService} from 'src/app/services/user.service';

import { Iuser } from 'src/app/Iproduct';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  //productList: Product[] = []
  users : Iuser [] = [];
  constructor(private dataService: ServiceService) { }
  
  //constructor(private productService: ProductService) { }

  ngOnInit() {
    this.getUsers();
  }
  getUsers(){

    this.dataService.getUsers().subscribe(allUsers => this.users = allUsers );
 
  }
 
 

}
