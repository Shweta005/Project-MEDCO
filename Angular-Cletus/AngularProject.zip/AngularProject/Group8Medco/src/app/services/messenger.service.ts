import { Injectable } from '@angular/core';
import { Subject } from 'rxjs'
import { Iuser } from '../Iproduct';


@Injectable({
  providedIn: 'root'
})
export class MessengerService {
  product: Iuser;
  subject = new Subject()

  constructor() { }

  sendMsg(product) {
    this.subject.next(product) //Triggering an event
  }

  getMsg() {
    return this.subject.asObservable()
  }
}
