import { Injectable } from '@angular/core';

import { Product } from 'src/app/models/product'

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  products: Product[] = [
    new Product(1, 'Honitos', 'This is the product 1 description. The product is really kool!', 100),
    new Product(2, ' Bendril', 'This is the product 2 description. The product is really kool!', 150),
    new Product(3, 'Kofol', 'This is the product 3 description. The product is really kool!', 50),
    new Product(4, 'EF-top', 'This is the product 4 description. The product is really kool!', 200),
    new Product(5, 'AFCORIL', 'This is the product 5 description. The product is really kool!', 100),
    new Product(6, 'Zincovit', 'This is the product 6 description. The product is really kool!', 150),
    new Product(7, 'JoDFLEX', 'This is the product 7 description. The product is really kool!', 250),
    new Product(8, 'CROCIN', 'This is the product 8 description. The product is really kool!', 300),
  ]

  constructor() { }

  getProducts(): Product[] {
    //TODO: Populate products from an API and return an Observable
    return this.products
  }
}
