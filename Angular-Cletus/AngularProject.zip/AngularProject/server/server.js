const express = require('express');

const product = require('./products/product');

const app = express();

const port = 3000;

const cors = require('cors');

const CORS_OPTIONS = {

    origin : 'http://localhost:4200',

    optionSuccessStatus:200

}

app.use(express.json())

app.use(express.urlencoded({extended:true}));

app.use(cors(CORS_OPTIONS));

app.get('/',(req,res)=>{

    //  res.sendFile('index.html');
  
    res.send("Welcome");
  
  }) 
  app.get('/users',(req,res)=>{
  
      res.json(product);
  
  })
   
  app.get('/user/:id',(req,res)=>{
  
      let id = req.params.id ;
  
      let index = product.findIndex((product)=>{
  
          return (product.id == Number.parseInt(id));
  
      })
  
     // console.log(index);
  
      let us = product[index];
  
      console.log(us);
  
      res.send(us);  
  
  })
// app.post('/users',(req,res)=>{

//     if(!req.body.name){

//         res.status(400);

//        return res.json({error:"email is not found"});

//     }

//     res.send(req.body);

//     const product = {

//         id:product.length + 1,

//         name:req.body.name

//     }

//     product.push(product);

//     res.json(user);

// })

// app.put('/users/:id',(req,res)=>{

//     let id = req.params.id ;

//     let name = req.body.name;

//     let index = users.findIndex((user)=>{

//         return (user.id ==Number.parseInt(id));

//     })

//     if(index >= 0){

//     let us = product[index]

//     us.name = name;

//     res.json(us);

//    }

//    else{

//        res.status(404);

//        res.json({error:"NO index"});

//    }

  

// })

// app.delete('/users/:id',(req,res)=>{

//     let id = req.params.id ;

//      let name = req.body.name;

//      let index = product.findIndex((user)=>{

//          return (product.id ==Number.parseInt(id));

//      })

//      if(index >= 0){

//         let us = product[index]

//         product.splice(index,1)

//         res.json(us);

//        }

//        else{

//            res.status(404);

//            res.end();

//        }

// })
app.listen(port,()=>{

    console.log(`http://localhost:${port} started `);

})