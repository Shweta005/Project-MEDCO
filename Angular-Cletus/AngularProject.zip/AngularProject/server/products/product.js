 var product = [
//     {
//         "id": 01,
//         "firstName": "Shweta"
//     },
//     {
//       "id": 02,
//       "firstName": "Sachin"
//     },
//   {
//       "id": 03,
//       "firstName": "Cletus"
//   } ]

    {"id":1, "name":"Honitos", "description":"This is the product 1 description. The product is really kool!", "price":100 ,"imageUrl" : "https://www.netmeds.com/images/product-v1/600x600/15912/dabur_honitus_herbal_cough_remedy_syrup_100_ml_0.jpg"},
    {"id":2,"name":"Bendril", "description":"This is the product 2 description. The product is really kool!", "price":100 ,"imageUrl" : "https://www.netmeds.com/images/product-v1/600x600/15912/dabur_honitus_herbal_cough_remedy_syrup_100_ml_0.jpg"},
    {"id":3, "name":"Kofol",   "description":"This is the product 3 description. The product is really kool!", "price":100 ,"imageUrl" : "https://www.netmeds.com/images/product-v1/600x600/15912/dabur_honitus_herbal_cough_remedy_syrup_100_ml_0.jpg"},
    {"id":4, "name":"EF-top",  "description":"This is the product 4 description. The product is really kool!", "price":100 ,"imageUrl" : "https://www.netmeds.com/images/product-v1/600x600/15912/dabur_honitus_herbal_cough_remedy_syrup_100_ml_0.jpg"},
 ]
  module.exports = product;